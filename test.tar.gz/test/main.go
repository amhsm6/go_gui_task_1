package main

import (
    "github.com/gotk3/gotk3/gtk"
    "log"
    "fmt"
)

func button_label(button_counter int) string {
    return fmt.Sprintf("%d", button_counter)
}

func main() {
    gtk.Init(nil)

    win, err := gtk.WindowNew(gtk.WINDOW_TOPLEVEL)
    if err != nil {
        log.Panic(err)
    }

    win.Connect("destroy", func() {
        gtk.MainQuit()
    });

    box, err := gtk.BoxNew(gtk.ORIENTATION_VERTICAL, 12)
    if err != nil {
        log.Panic(err)
    }

    win.Add(box)

    var button_counter int
    positions := make(map[string]int)
    positions["0"] = -1

    var click_handler func(*gtk.Button)
    click_handler = func(b *gtk.Button) {
        var caller_id string
        if b == nil {
            caller_id = "0"
        } else {
            caller_id = fmt.Sprint(b.Object)
        }
        new_pos := positions[caller_id] + 1

        button_counter += 1

        button, err := gtk.ButtonNewWithLabel(button_label(button_counter))
        if err != nil {
            log.Panic(err)
        }

        box.Add(button)

        box.GetChildren().Foreach(func(foo any) {
            btn, ok := foo.(*gtk.Widget)
            if !ok { return }

            btn_id := fmt.Sprint(btn.Object)
            if positions[btn_id] >= new_pos {
                positions[btn_id] += 1
            }
        })

        positions[fmt.Sprint(button.Object)] = new_pos
        box.ReorderChild(button, new_pos)

        button.Connect("clicked", click_handler)
        button.Show()
    }

    click_handler(nil)

    win.ShowAll()

    gtk.Main()
}
